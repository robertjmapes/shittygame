import pygame

width = 500
height = 500

BLACK = (0,0,0)
WHITE = (255,255,255)

walkDown = [pygame.image.load("images/char/char_01.png"),
			pygame.image.load("images/char/char_02.png"),
			pygame.image.load("images/char/char_03.png")]
walkRight = [pygame.image.load("images/char/char_04.png"),
			pygame.image.load("images/char/char_05.png"),
			pygame.image.load("images/char/char_06.png")]
walkUp = [pygame.image.load("images/char/char_07.png"),
		  pygame.image.load("images/char/char_08.png"),
		  pygame.image.load("images/char/char_09.png")]
walkLeft = [pygame.image.load("images/char/char_10.png"),
			pygame.image.load("images/char/char_11.png"),
			pygame.image.load("images/char/char_12.png")]

eWalkDown = [pygame.image.load("images/enemy/chad_01.png"), 
			 pygame.image.load("images/enemy/chad_02.png"),
			 pygame.image.load("images/enemy/chad_03.png")]
eWalkRight = [pygame.image.load("images/enemy/chad_04.png"), 
			 pygame.image.load("images/enemy/chad_05.png"),
			 pygame.image.load("images/enemy/chad_06.png")]
eWalkUp = [pygame.image.load("images/enemy/chad_07.png"), 
			 pygame.image.load("images/enemy/chad_08.png"),
			 pygame.image.load("images/enemy/chad_09.png")]
eWalkLeft = [pygame.image.load("images/enemy/chad_10.png"), 
			 pygame.image.load("images/enemy/chad_11.png"),
			 pygame.image.load("images/enemy/chad_12.png")]

enemyMessages = ["LLLLLLLLLLLLLLLLLLLLLLLL",
				"Today is your unlucky day..."]

def drawDialouge(window, message):
	pygame.draw.rect(window, WHITE, (0,400,500,500))
	font = pygame.font.SysFont(None, 25)
	txt = font.render(message, True, BLACK)
	window.blit(txt, (0,400))
	pygame.draw.polygon(window, BLACK, [(460,480),(470, 485),(460,490)])
