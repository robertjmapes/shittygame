import pygame, random, time
from config import *

class mainEnemy:
	def __init__(self, x, y, img):
		self.img = img
		self.x = x
		self.y = y
		self.width = 41
		self.height = 36
		self.counter = 0
	def interaction(self, window, player):
		if player.x+player.width > self.x and player.x < self.x+self.width:
			if player.y < self.y + self.height + 5:
				player.locked = True
				drawDialouge(window, "Time to die, sorry?")
				player.battle = True
								
	def draw(self, window):
		window.blit(self.img,(self.x,self.y))
		pygame.draw.rect(window, (255,0,0), (self.x, self.y, self.width, self.height), 2)

	



		
