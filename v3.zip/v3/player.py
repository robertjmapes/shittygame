import pygame
from config import *

class Player:
	def __init__(self):
		self.velocity = 2
		self.locked = False
		self.width = 41
		self.height = 36
		self.x = width/2
		self.y = height/2
		self.right = False
		self.left = False
		self.up = False
		self.down = False
		self.walkCount = 0
		self.walkLeft = walkLeft
		self.walkRight = walkRight
		self.walkDown = walkDown
		self.walkUp = walkUp
		self.hitbox = (self.x, self.y, self.width, self.height)
		self.battle = False
	def movement(self):
		keys = pygame.key.get_pressed()
		if keys[pygame.K_a] and self.x > 0:
			self.x -= self.velocity
			self.left, self.right = True, False
			self.up, self.down = False, False
		elif keys[pygame.K_d] and self.x < (width - self.width):
			self.x += self.velocity
			self.left, self.right = False, True
			self.up, self.down = False, False
		elif keys[pygame.K_w] and self.y > 0:
			self.y -= self.velocity
			self.left, self.right = False, False
			self.up, self.down = True, False
		elif keys[pygame.K_s] and self.y < (height - self.height):
			self.y += self.velocity
			self.left, self.right = False, False
			self.up, self.down = False, True
		else:
			self.left, self.right = False, False
			self.up, self.down = False, False       
			self.walkCount = 0
	def draw(self, window):
		if self.locked == True:
			self.walkCount = 0
		if self.walkCount+1 >= 9:
			self.walkCount = 0
		if self.left:
			window.blit(self.walkLeft[self.walkCount//3], (self.x,self.y))
			self.walkCount += 1
		elif self.right:
			window.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
			self.walkCount += 1
		elif self.up:
			window.blit(self.walkUp[self.walkCount//3], (self.x,self.y))
			self.walkCount += 1
		elif self.down:
			window.blit(self.walkDown[self.walkCount//3], (self.x,self.y))
			self.walkCount += 1
		else:
			window.blit(pygame.image.load("images/char/char_02.png"),(self.x,self.y))
			self.walkCount = 0
		self.hitbox = (self.x, self.y, self.width, self.height)
		pygame.draw.rect(window, (255,0,0), self.hitbox, 2)
	def fight(self):
		pass


			
	
		
		
