import pygame
from config import *

class interactiveObject:
	def __init__(self, img, x, y, width, height):
		self.img = img
		self.x = x
		self.y = y
		self.width = width
		self.height = height
		self.hitbox = (self.x, self.y, self.width, self.height)
	def interaction(self, message, player, window):
		keys = pygame.key.get_pressed()
		if player.y < self.y+self.height and player.y > self.y:
			if player.x > self.x and player.x < self.x:
				if keys[pygame.K_e]:
					pygame.draw.rect(window, (255,255,255), (0,400,500,500))

	def draw(self, window):
		self.hitbox = (self.x, self.y, self.width, self.height)
		pygame.draw.rect(window, (255,0,0), self.hitbox, 2)
