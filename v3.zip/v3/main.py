import pygame, random
from player import Player
from enemy import *
from objects import *
from config import *

pygame.init()
pygame.display.set_caption("Blank")

window = pygame.display.set_mode((width, height))
clock = pygame.time.Clock()

player = Player()
enemy = mainEnemy(450,15,eWalkDown[1])

run = True
while run:
	window.fill((0,0,0))
	for event in pygame.event.get():
		print(event)
		if event.type == pygame.QUIT:
			run = False

	if player.locked == False:
		player.movement()
	if player.battle == True:
		player.fight()
	
	player.draw(window)
	enemy.draw(window)
	enemy.interaction(window, player)

	pygame.display.update()
	clock.tick(30)

pygame.quit()
	

