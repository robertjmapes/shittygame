import pygame, random
from player import Player  

pygame.init()
pygame.display.set_caption("Blank")

window = pygame.display.set_mode((1500, 900))
clock = pygame.time.Clock()

player = Player()


run = True
while run:
    window.fill((0,0,0))
    for event in pygame.event.get():
        print(event)
        if event.type == pygame.QUIT:
            run = False
            
    player.movement()
    player.draw(window)
    
    pygame.display.update()
    clock.tick(30)

    
pygame.quit()
    

