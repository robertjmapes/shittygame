import pygame

class Player:
    def __init__(self):
        self.velocity = 5
        self.width = 64
        self.height = 64
        self.x = 400
        self.y = 300
        self.right = False
        self.left = False
        self.up = False
        self.down = False  
    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_a] and self.x > 0:
            self.x -= self.velocity
            self.left, self.right = True, False
            self.up, self.down = False, False
        elif keys[pygame.K_d] and self.x < (1500 - self.width):
            self.x += self.velocity
            self.left, self.right = False, True
            self.up, self.down = False, False
        elif keys[pygame.K_w] and self.y > 0:
            self.y -= self.velocity
            self.left, self.right = False, False
            self.up, self.down = True, False
        elif keys[pygame.K_s] and self.y < (900 - self.height):
            self.y += self.velocity
            self.left, self.right = False, False
            self.up, self.down = False, True
    def draw(self, window):
        if self.left:
            window.blit(pygame.image.load("images/char/char_11.gif"), (self.x,self.y))
        elif self.right:
            window.blit(pygame.image.load("images/char/char_05.gif"), (self.x,self.y))
        elif self.up:
            window.blit(pygame.image.load("images/char/char_08.gif"), (self.x,self.y))
        elif self.down:
            window.blit(pygame.image.load("images/char/char_02.gif"), (self.x,self.y))

            
    
        
        
